# SimpleCrawler
This is an simple, ethical crawler made in python
